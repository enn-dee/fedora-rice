# Fedora Hyprland / ML4W Rice — backup

- Created: 2026-10-17
- Host:    fedora

## What's inside

| payload path            | restores to        | contents                                   |
|-------------------------|--------------------|--------------------------------------------|
| `payload/mydotfiles/`   | `~/.mydotfiles`     | all ML4W configs (hypr, quickshell, waybar, rofi, kitty, ...) + wallpapers |
| `payload/config/`       | `~/.config`         | extra configs I own (ml4w-statusbar, ghostty, cava, ...) |
| `payload/local-share/`  | `~/.local/share`    | JetBrainsMono Nerd Font, kora icon theme, ML4W Quickshell apps |
| `payload/home/`         | `~`                 | `.oh-my-zsh`, `.zsh`                        |
| `symlinks.txt`          | —                  | recreates the `~/.config/*` + `~/.*` symlinks into `~/.mydotfiles` |
| `packages/`             | —                  | package list from the source machine       |
| `rice-backup.sh`        | —                  | re-run this to make a fresh backup later   |

## Restore on a fresh install

```
tar -xzf fedora-rice-2026-10-17.tar.gz
cd fedora-rice-2026-10-17
./restore.sh
```

Then log out and back in. `restore.sh` is safe to re-run and never deletes
your files (anything in the way is moved to `*.pre-rice-restore-*`).

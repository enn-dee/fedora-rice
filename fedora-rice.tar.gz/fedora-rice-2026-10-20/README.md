# Fedora Rice — Niri + DankMaterialShell (main) / Hyprland + ML4W (fallback)

- Created: 2026-10-20
- Host:    fedora

## Sessions

- **Niri** is the default GDM session (saved in AccountsService as `Session=niri`).
- **Hyprland / ML4W** stays installed and selectable at the login screen as a
  fallback. Nothing is removed by this backup or its restore.

## What's inside

| payload path            | restores to        | contents                                   |
|-------------------------|--------------------|--------------------------------------------|
| `payload/mydotfiles/`   | `~/.mydotfiles`     | all ML4W configs (hypr, quickshell, waybar, rofi, kitty, ...) + wallpapers |
| `payload/config/`       | `~/.config`         | niri (`config.kdl` + `dms/*.kdl`), DankMaterialShell settings, ml4w-statusbar, ghostty, cava, ... |
| `payload/local-share/`  | `~/.local/share`    | JetBrainsMono Nerd Font, kora icon theme, ML4W Quickshell apps, matugen color-schemes |
| `payload/local-state/`  | `~/.local/state`    | DMS `session.json` (remembered wallpaper)  |
| `payload/wallpapers/`   | original path       | active wallpaper + `wallpaper-path.txt`    |
| `payload/home/`         | `~`                 | `.oh-my-zsh`, `.zsh`                        |
| `symlinks.txt`          | —                  | recreates the `~/.config/*` + `~/.*` symlinks into `~/.mydotfiles` |
| `packages/`             | —                  | package list from the source machine       |
| `rice-backup.sh`        | —                  | re-run this to make a fresh backup later   |

## Restore on a fresh install

```
tar -xzf fedora-rice-2026-10-20.tar.gz
cd fedora-rice-2026-10-20
./restore.sh
```

Then log out and back in. `restore.sh` is safe to re-run and never deletes
your files (anything in the way is moved to `*.pre-rice-restore-*`).

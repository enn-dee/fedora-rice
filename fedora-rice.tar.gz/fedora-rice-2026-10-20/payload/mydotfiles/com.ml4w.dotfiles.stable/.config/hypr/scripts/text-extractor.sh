#!/usr/bin/env bash
# Script by https://github.com/anshifmonz

set -Eeuo pipefail

PICKER_PID=""
SLURP_TIMEOUT=10
DEPS=(grim slurp magick tesseract wl-copy timeout)

die() { echo "Error: $*" >&2; exit 1; }
safe_kill() { [[ -n "${1:-}" ]] && kill "$1" 2>/dev/null || true; }
cleanup() { safe_kill "$PICKER_PID"; }
trap cleanup EXIT INT TERM

# Check dependencies
check_deps() {
  local missing_dependencies=()
  for dep in "${DEPS[@]}"; do command -v "$dep" >/dev/null 2>&1 || missing_dependencies+=("$dep"); done
  if (( ${#missing_dependencies[@]} > 0 )); then
    die "Missing dependencies: ${missing_dependencies[*]}"
  fi
}

# Check if command exists
_checkCommandExists() {
    cmd="$1"
    if ! command -v "$cmd" >/dev/null; then
        echo 1
        return
    fi
    echo 0
    return
}

check_deps

# Arch
if [[ $(_checkCommandExists "pacman") == 0 ]]; then
    OCR_LANGUAGE_LIST="$(pacman -Qq | grep -iE "tesseract-(ocr|data|langpack)*-" | awk -F '-' '{print $NF}')"
# Fedora
elif [[ $(_checkCommandExists "dnf") == 0 ]]; then
    OCR_LANGUAGE_LIST="$(dnf list --installed | grep -iE "tesseract-(ocr|data|langpack)*-" | awk -F '-' '{print $NF}')"
# Opensuse
else
    OCR_LANGUAGE_LIST="$(zypper se -i | grep -iE "tesseract-(ocr|data|langpack)*-" | awk -F '-' '{print $NF}')"
fi

argc() { echo $#; }
rofi_cmd() {
    $HOME/.config/ml4w/scripts/ml4w-launcher dmenu -c ~/.config/rofi/config-ocr-lang.rasi -l 3 -p "Select the OCR language" --rofi-args "-no-show-icons -width 30"
}

if [ "$(argc $OCR_LANGUAGE_LIST)" -gt 1 ]; then
    OCR_LANGUAGE=$(echo -e "$OCR_LANGUAGE_LIST" | rofi_cmd)
    sleep 0.5 || true
fi

if [ -z "$OCR_LANGUAGE" ]; then
    OCR_LANGUAGE="eng"
fi

hyprpicker -r -z &
PICKER_PID=$!
sleep 0.1 || true

REGION=$(timeout "$SLURP_TIMEOUT" slurp -b "#00000080" -c "#888888ff" -w 1) || die "No region selected (timeout or cancelled)"
[[ -z "$REGION" ]] && die "No region selected"
cleanup

grim -g "$REGION" - \
  | magick - -colorspace Gray -normalize -contrast-stretch 2% -sharpen 0x1.0 -resize 200% png:- \
  | tesseract - stdout -l $OCR_LANGUAGE --psm 6 \
  | wl-copy \
  || die "Failed to capture or process text"


background = "rgba(0e1415ff)"

error = "rgba(ffb4abff)"

error_container = "rgba(93000aff)"

inverse_on_surface = "rgba(2b3232ff)"

inverse_primary = "rgba(006970ff)"

inverse_surface = "rgba(dee4e4ff)"

on_background = "rgba(dee4e4ff)"

on_error = "rgba(690005ff)"

on_error_container = "rgba(ffdad6ff)"

on_primary = "rgba(00363bff)"

on_primary_container = "rgba(9df0f9ff)"

on_primary_fixed = "rgba(002022ff)"

on_primary_fixed_variant = "rgba(004f55ff)"

on_secondary = "rgba(1b3437ff)"

on_secondary_container = "rgba(cce8eaff)"

on_secondary_fixed = "rgba(051f21ff)"

on_secondary_fixed_variant = "rgba(324b4dff)"

on_surface = "rgba(dee4e4ff)"

on_surface_variant = "rgba(bec8c9ff)"

on_tertiary = "rgba(21304cff)"

on_tertiary_container = "rgba(d7e2ffff)"

on_tertiary_fixed = "rgba(0b1b36ff)"

on_tertiary_fixed_variant = "rgba(384764ff)"

outline = "rgba(899393ff)"

outline_variant = "rgba(3f4849ff)"

primary = "rgba(80d4dcff)"

primary_container = "rgba(004f55ff)"

primary_fixed = "rgba(9df0f9ff)"

primary_fixed_dim = "rgba(80d4dcff)"

scrim = "rgba(000000ff)"

secondary = "rgba(b1cbceff)"

secondary_container = "rgba(324b4dff)"

secondary_fixed = "rgba(cce8eaff)"

secondary_fixed_dim = "rgba(b1cbceff)"

shadow = "rgba(000000ff)"

source_color = "rgba(7bb5bbff)"

surface = "rgba(0e1415ff)"

surface_bright = "rgba(343a3bff)"

surface_container = "rgba(1a2121ff)"

surface_container_high = "rgba(252b2cff)"

surface_container_highest = "rgba(303637ff)"

surface_container_low = "rgba(161d1dff)"

surface_container_lowest = "rgba(090f10ff)"

surface_dim = "rgba(0e1415ff)"

surface_tint = "rgba(80d4dcff)"

surface_variant = "rgba(3f4849ff)"

tertiary = "rgba(b7c7eaff)"

tertiary_container = "rgba(384764ff)"

tertiary_fixed = "rgba(d7e2ffff)"

tertiary_fixed_dim = "rgba(b7c7eaff)"



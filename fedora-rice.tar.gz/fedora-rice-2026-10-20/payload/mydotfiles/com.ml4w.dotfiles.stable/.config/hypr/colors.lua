
background = "rgba(1a1111ff)"

error = "rgba(ffb4abff)"

error_container = "rgba(93000aff)"

inverse_on_surface = "rgba(382e2eff)"

inverse_primary = "rgba(8f4a4fff)"

inverse_surface = "rgba(f0dedeff)"

on_background = "rgba(f0dedeff)"

on_error = "rgba(690005ff)"

on_error_container = "rgba(ffdad6ff)"

on_primary = "rgba(561d23ff)"

on_primary_container = "rgba(ffdadaff)"

on_primary_fixed = "rgba(3b0810ff)"

on_primary_fixed_variant = "rgba(723338ff)"

on_secondary = "rgba(44292bff)"

on_secondary_container = "rgba(ffdadaff)"

on_secondary_fixed = "rgba(2c1516ff)"

on_secondary_fixed_variant = "rgba(5d3f40ff)"

on_surface = "rgba(f0dedeff)"

on_surface_variant = "rgba(d7c1c2ff)"

on_tertiary = "rgba(432c06ff)"

on_tertiary_container = "rgba(ffddb2ff)"

on_tertiary_fixed = "rgba(291800ff)"

on_tertiary_fixed_variant = "rgba(5c421aff)"

outline = "rgba(9f8c8cff)"

outline_variant = "rgba(524343ff)"

primary = "rgba(ffb3b6ff)"

primary_container = "rgba(723338ff)"

primary_fixed = "rgba(ffdadaff)"

primary_fixed_dim = "rgba(ffb3b6ff)"

scrim = "rgba(000000ff)"

secondary = "rgba(e6bdbeff)"

secondary_container = "rgba(5d3f40ff)"

secondary_fixed = "rgba(ffdadaff)"

secondary_fixed_dim = "rgba(e6bdbeff)"

shadow = "rgba(000000ff)"

source_color = "rgba(c74756ff)"

surface = "rgba(1a1111ff)"

surface_bright = "rgba(413737ff)"

surface_container = "rgba(271d1eff)"

surface_container_high = "rgba(322828ff)"

surface_container_highest = "rgba(3d3232ff)"

surface_container_low = "rgba(22191aff)"

surface_container_lowest = "rgba(140c0cff)"

surface_dim = "rgba(1a1111ff)"

surface_tint = "rgba(ffb3b6ff)"

surface_variant = "rgba(524343ff)"

tertiary = "rgba(e7c08dff)"

tertiary_container = "rgba(5c421aff)"

tertiary_fixed = "rgba(ffddb2ff)"

tertiary_fixed_dim = "rgba(e7c08dff)"



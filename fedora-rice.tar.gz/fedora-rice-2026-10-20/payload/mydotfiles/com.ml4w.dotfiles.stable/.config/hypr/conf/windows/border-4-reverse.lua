hl.config({
    general = {
        gaps_in  = 10,
        gaps_out = 16,
        border_size = 4,
        col = {
            active_border = primary,
            inactive_border = on_primary,
        },
        resize_on_border = true,
        allow_tearing = false,
        layout = "dwindle",
    }
})
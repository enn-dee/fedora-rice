local name = "default.lua"
load_variant(name,"windows")

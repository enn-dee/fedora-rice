hl.config({
    general = {
        gaps_in  = 10,
        gaps_out = 16,
        border_size = 3,
        col = {
            active_border = on_primary,
            inactive_border = primary,
        },
        resize_on_border = true,
        allow_tearing = false,
        layout = "dwindle",
    }
})
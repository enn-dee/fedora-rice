#!/bin/bash
theme_name="ML4W Minimal"

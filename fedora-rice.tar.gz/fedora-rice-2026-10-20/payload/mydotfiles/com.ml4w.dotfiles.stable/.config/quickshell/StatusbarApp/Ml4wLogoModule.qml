import Quickshell
import QtQuick
import qs.CustomTheme

// Custom "ND" logo -> toggles the Sidebar app via IPC.
Rectangle {
    implicitWidth: 30
    implicitHeight: 30
    radius: 15

    color: mouseArea.containsMouse ? Theme.primary : "transparent"
    Behavior on color {
        ColorAnimation { duration: 500; easing.type: Easing.OutQuint }
    }

    Text {
        anchors.centerIn: parent
        text: "ND"
        font.bold: true
        font.pixelSize: 11
        color: "#FFFFFF"
        Behavior on color {
            ColorAnimation { duration: 500; easing.type: Easing.OutQuint }
        }
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: {
            Quickshell.execDetached(["qs", "ipc", "call", "sidebar", "toggle"])
        }
    }
}

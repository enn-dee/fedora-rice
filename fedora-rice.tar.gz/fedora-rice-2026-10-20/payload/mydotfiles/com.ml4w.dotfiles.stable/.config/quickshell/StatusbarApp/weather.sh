#!/usr/bin/env bash
set -u

fetch_url() {
    local url="$1"
    local out
    for _ in 1 2 3; do
        out="$(curl -fsS --max-time 10 "$url" 2>/dev/null)" && {
            printf '%s' "$out"
            return 0
        }
        sleep 1
    done
    printf '{}'
}

unit_file="$HOME/.config/quickshell/StatusbarApp/weather-unit.txt"
cache_file="$HOME/.config/quickshell/StatusbarApp/weather-cache.txt"
location_file="$HOME/.config/quickshell/StatusbarApp/weather-location.txt"

UNIT="C"
if [ -f "$unit_file" ]; then
    u="$(tr -d '\r\n' < "$unit_file" | tr '[:lower:]' '[:upper:]')"
    case "$u" in C|F) UNIT="$u" ;; esac
fi

user_loc=""
if [ -f "$location_file" ]; then
    user_loc="$(tr -d '\r\n' < "$location_file" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
fi

LAT=""
LON=""
PLACE_NAME=""

if [ -n "$user_loc" ]; then
    if printf '%s' "$user_loc" | grep -Eq '^-?[0-9]+(\.[0-9]+)?[ ]*,[ ]*-?[0-9]+(\.[0-9]+)?$'; then
        LAT="$(printf '%s' "$user_loc" | cut -d, -f1 | tr -d ' ')"
        LON="$(printf '%s' "$user_loc" | cut -d, -f2 | tr -d ' ')"
        PLACE_NAME="Pinned"
    else
        ENCODED="$(python3 -c 'import urllib.parse, sys; print(urllib.parse.quote(sys.argv[1]))' "$user_loc")"
        geo_json="$(fetch_url "https://geocoding-api.open-meteo.com/v1/search?name=${ENCODED}&count=1&language=en")"
        read -r LAT LON PLACE_NAME <<EOF
$(printf '%s' "$geo_json" | python3 -c 'import sys, json
try:
    d = json.load(sys.stdin)
    r = (d.get("results") or [{}])[0]
    print(r.get("latitude", ""), r.get("longitude", ""), r.get("name", ""))
except Exception:
    print("", "", "")
')
EOF
        if [ -z "$PLACE_NAME" ]; then PLACE_NAME="$user_loc"; fi
    fi
fi

if [ -z "$LAT" ] || [ -z "$LON" ]; then
    ip_json="$(fetch_url "https://ipinfo.io/json")"
    read -r LAT LON PLACE_NAME <<EOF
$(printf '%s' "$ip_json" | python3 -c 'import sys, json
try:
    d = json.load(sys.stdin)
    loc = str(d.get("loc", "0,0")).split(",")
    print(loc[0] if len(loc) > 0 else "", loc[1] if len(loc) > 1 else "", d.get("city", ""))
except Exception:
    print("", "", "")
')
EOF
fi

if [ -z "$LAT" ] || [ -z "$LON" ]; then
    LAT="37.8"; LON="-122.3"; PLACE_NAME="Default"
fi

param_unit="celsius"
[ "$UNIT" = "F" ] && param_unit="fahrenheit"

wx_json="$(fetch_url "https://api.open-meteo.com/v1/forecast?latitude=${LAT}&longitude=${LON}&current=temperature_2m,weather_code,relative_humidity_2m,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=3&timezone=auto&temperature_unit=${param_unit}")"

printf '%s' "$wx_json" | python3 -c '
import sys, json
from datetime import datetime

city = sys.argv[1] if len(sys.argv) > 1 else ""
unit = sys.argv[2] if len(sys.argv) > 2 else "C"
icons = {
    0:"☀️",1:"🌤️",2:"⛅",3:"☁️",45:"🌫️",48:"🌫️",
    51:"🌦️",53:"🌦️",55:"🌧️",61:"🌧️",63:"🌧️",65:"🌧️",
    66:"🌨️",67:"🌨️",71:"🌨️",73:"🌨️",75:"🌨️",77:"🌨️",
    80:"🌦️",81:"🌧️",82:"🌧️",85:"🌨️",86:"🌨️",
    95:"⛈️",96:"⛈️",99:"⛈️"
}

try:
    d = json.load(sys.stdin)
    cur = d.get("current", {}) or {}
    temp = cur.get("temperature_2m")
    code = cur.get("weather_code", -1)
    hum = cur.get("relative_humidity_2m", 0)
    wind = cur.get("wind_speed_10m", 0)
    daily = d.get("daily", {}) or {}
    times = daily.get("time", []) or []
    codes = daily.get("weather_code", []) or []
    highs = daily.get("temperature_2m_max", []) or []
    lows = daily.get("temperature_2m_min", []) or []
    fc = []
    # Show today + next two days.
    for i in range(min(3, len(times))):
        try:
            day = datetime.strptime(times[i], "%Y-%m-%d").strftime("%a")
        except Exception:
            day = "Day %d" % (i + 1)
        fc.append({
            "d": day,
            "icon": icons.get(codes[i] if i < len(codes) else -1, "🌡️"),
            "max": highs[i] if i < len(highs) else None,
            "min": lows[i] if i < len(lows) else None
        })
    out = {
        "city": city,
        "icon": icons.get(code, "🌡️"),
        "temp": temp,
        "unit": unit,
        "humidity": hum,
        "wind": wind,
        "forecast": fc
    }
except Exception:
    out = {
        "city": city,
        "icon": "🌡️",
        "temp": None,
        "unit": unit,
        "humidity": 0,
        "wind": 0,
        "forecast": []
    }

import json as _j
print(_j.dumps(out, ensure_ascii=False))
' "$PLACE_NAME" "$UNIT" | tee "$cache_file"

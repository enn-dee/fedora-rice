import Quickshell
import QtQuick

// Region screenshot with grim + slurp, saved to ~/Pictures/Screenshots.
BarButton {
    iconSrc: "../shared/icons/screenshot.svg"
    onClicked: {
        Quickshell.execDetached(["bash", "-c",
            "mkdir -p ~/Pictures/Screenshots && grim -g \"$(slurp)\""
            + " ~/Pictures/Screenshots/$(date +%s).png"])
    }
}

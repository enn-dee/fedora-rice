#!/usr/bin/env bash
set -u

file="$HOME/.config/quickshell/StatusbarApp/weather-location.txt"
mkdir -p "$(dirname "$file")"

#!/usr/bin/env bash
set -u

file="$HOME/.config/quickshell/StatusbarApp/weather-location.txt"
mkdir -p "$(dirname "$file")"

current=""
if [ -f "$file" ]; then
    current="$(tr -d '\r\n' < "$file")"
fi

# Prefer rofi (live suggestions via geocoding); fall back to zenity.
if command -v rofi >/dev/null 2>&1; then
    choice="$(rofi -dmenu -i -p "Weather location" \
        -modi "weather:$HOME/.config/quickshell/StatusbarApp/weather-city-suggest.sh" \
        -show weather 2>/dev/null)" || choice=""
else
    choice="$(zenity --entry \
        --title="Weather location" \
        --text="Enter a city name or latitude,longitude:" \
        --entry-text="$current" 2>/dev/null)" || choice=""
fi

# Normalise: "Srinagar, Jammu ... (India)" -> "Srinagar"; keep lat,lon intact.
if printf '%s' "$choice" | grep -Eq '^-?[0-9]+(\.[0-9]+)?[ ]*,[ ]*-?[0-9]+(\.[0-9]+)?$'; then
    :
else
    choice="$(printf '%s' "$choice" | sed -E 's/\(.*\)//; s/,.*//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
fi

choice="$(printf '%s' "$choice" | tr -d '\r\n' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
[ -z "$choice" ] && exit 0

printf '%s\n' "$choice" > "$file"
qs ipc call weather refresh >/dev/null 2>&1 || true

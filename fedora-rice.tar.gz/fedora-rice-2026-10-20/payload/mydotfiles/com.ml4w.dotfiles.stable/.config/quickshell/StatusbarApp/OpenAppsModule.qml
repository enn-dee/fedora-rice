import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import qs.CustomTheme

// Lists currently opened windows (apps) as clickable chips, so you can see
// what's running and jump to it. Reads Hyprland's client list via hyprctl.
RowLayout {
    id: winList
    spacing: 8

    property var windows: []

    function refresh(): void {
        clientsProc.running = false
        clientsProc.running = true
    }

    Process {
        id: clientsProc
        command: ["bash", "-c", "hyprctl clients -j 2>/dev/null"]
        stdout: StdioCollector {
            onStreamFinished: {
                let text = this.text.trim()
                if (text === "") { winList.windows = []; return }
                let arr
                try { arr = JSON.parse(text) } catch (e) { winList.windows = []; return }
                // Only show normal, non-floating special windows; skip the
                // statusbar itself and the dock/overview/powermenu.
                let filtered = arr.filter(function (w) {
                    return !w.pinned
                        && w.workspace.name !== "special"
                        && w.class !== ""
                        && w.title !== ""
                })
                winList.windows = filtered
            }
        }
    }

    Timer {
        interval: 2000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: winList.refresh()
    }

    Repeater {
        model: winList.windows
        delegate: Rectangle {
            id: chip
            implicitWidth: 120
            implicitHeight: 24
            radius: 12
            color: "#FFFFFF22"
            Behavior on color { ColorAnimation { duration: 200 } }

            Text {
                anchors.centerIn: parent
                text: modelData.title.length > 22 ? modelData.title.slice(0, 20) + "…" : modelData.title
                color: "#FFFFFF"
                font.family: Theme.fontFamily
                font.pixelSize: 11
                font.bold: true
                elide: Text.ElideRight
            }

            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    // Focus this window's workspace and raise it.
                    Quickshell.execDetached(["hyprctl", "dispatch", "focuswindow", "class:" + modelData.class])
                }
            }
        }
    }

    Component.onCompleted: winList.refresh()
}

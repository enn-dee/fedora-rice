import Quickshell
import QtQuick

// Clipboard manager -> opens rofi's clipboard mode (greenclip), falling back
// to the app launcher if greenclip isn't installed.
BarButton {
    iconSrc: "../shared/icons/package.svg"
    onClicked: {
        Quickshell.execDetached(["bash", "-c",
            "rofi -modi 'clipboard:greenclip print' -show clipboard 2>/dev/null"
            + " || rofi -show drun"])
    }
}

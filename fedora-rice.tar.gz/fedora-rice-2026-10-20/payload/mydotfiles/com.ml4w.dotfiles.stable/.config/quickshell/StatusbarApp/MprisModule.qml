import Quickshell
import Quickshell.Io
import QtQuick
import qs.CustomTheme

// MPRIS media player info (artist - title) via playerctl.
// Click toggles play/pause; scroll not exposed here.
Item {
    id: mpris

    property bool focused: false
    property string text: "No music"
    property string playerIcon: "▶"

    implicitWidth: mprisText.implicitWidth + 6
    implicitHeight: 26

    Text {
        id: mprisText
        anchors.centerIn: parent
        text: mpris.playerIcon + " " + mpris.text
        color: "#FFFFFF"
        Behavior on color { ColorAnimation { duration: 200 } }
        elide: Text.ElideRight
        font.family: Theme.fontFamily
        font.pixelSize: 12
        font.bold: true
    }

    Rectangle {
        anchors.fill: parent
        radius: 13
        color: mpris.focused ? Theme.primary : "transparent"
        z: -1
        Behavior on color { ColorAnimation { duration: 500; easing.type: Easing.OutQuint } }
    }

    function refresh(): void {
        mprisProc.running = false
        mprisProc.running = true
    }

    Process {
        id: mprisProc
        command: ["bash", "-c",
            "playerctl status 2>/dev/null | head -n1"
            + " && playerctl metadata --format '{{artist}} - {{title}}' 2>/dev/null | head -n1"]
        stdout: StdioCollector {
            onStreamFinished: {
                let lines = this.text.split("\n")
                let status = (lines[0] || "").trim()
                let meta = (lines[1] || "").trim()
                mpris.playerIcon = (status === "Playing") ? "▶" : "⏸"
                mpris.text = meta === "" ? "No music" : meta
            }
        }
    }

    Timer {
        interval: 2000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: mpris.refresh()
    }

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: Quickshell.execDetached(["bash", "-c", "playerctl play-pause"])
    }

    IpcHandler {
        target: "mpris"
        function refresh(): void { mpris.refresh() }
    }
}

import Quickshell
import Quickshell.Io
import QtQuick
import qs.CustomTheme

// Compact live memory (RAM) usage module.
// Reads /proc/meminfo and shows the percentage of used RAM.
Item {
    id: ram

    property bool focused: false

    property string text: "RAM --%"

    function refresh(): void {
        ramProc.running = false
        ramProc.running = true
    }

    implicitWidth: ramText.implicitWidth + 6
    implicitHeight: 26

    Text {
        id: ramText
        anchors.centerIn: parent
        text: ram.text
        color: "#FFFFFF"
        Behavior on color { ColorAnimation { duration: 200 } }
        font.family: Theme.fontFamily
        font.pixelSize: 12
        font.bold: true
    }

    Rectangle {
        anchors.fill: parent
        radius: 13
        color: ram.focused ? Theme.primary : "transparent"
        z: -1
        Behavior on color { ColorAnimation { duration: 500; easing.type: Easing.OutQuint } }
    }

    Process {
        id: ramProc
        command: ["bash", "-c", "grep -E '^(MemTotal|MemAvailable|MemFree|Buffers|Cached):' /proc/meminfo"]
        stdout: StdioCollector {
            onStreamFinished: {
                let lines = this.text.trim().split("\n")
                let values = {}
                for (let i = 0; i < lines.length; i++) {
                    let parts = lines[i].trim().split(/\s+/)
                    if (parts.length >= 2)
                        values[parts[0].replace(":", "")] = Number(parts[1]) || 0
                }
                let total = values["MemTotal"] || 0
                let available = (values["MemAvailable"] !== undefined)
                    ? values["MemAvailable"]
                    : ((values["MemFree"] || 0) + (values["Buffers"] || 0) + (values["Cached"] || 0))
                if (total > 0) {
                    let used = total - available
                    let percent = 100.0 * used / total
                    ram.text = "RAM " + Math.round(percent) + "%"
                }
            }
        }
    }

    Timer {
        interval: 2000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: ram.refresh()
    }

    IpcHandler {
        target: "ram"
        function refresh(): void { ram.refresh() }
    }
}

import Quickshell
import QtQuick

// Cava audio visualizer launcher.
// cava is installed but rendering its inline waveform inside a QML module
// requires parsing cava's raw sample output, so this chip opens cava in a
// kitty terminal instead. Clicking it starts cava.
BarButton {
    iconSrc: "../shared/icons/launcher.svg"
    onClicked: {
        Quickshell.execDetached(["bash", "-c", "kitty -e cava"])
    }
}

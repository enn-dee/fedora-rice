import Quickshell
import QtQuick

// Color picker -> hyprpicker, copies the picked color to the clipboard.
BarButton {
    iconSrc: "../shared/icons/picker.svg"
    onClicked: {
        Quickshell.execDetached(["bash", "-c", "hyprpicker -a"])
    }
}

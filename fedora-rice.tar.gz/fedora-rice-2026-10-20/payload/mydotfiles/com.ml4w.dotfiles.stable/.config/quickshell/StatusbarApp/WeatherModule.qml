import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import qs.CustomTheme

// Compact-but-detailed weather card for the center status-bar island.
Item {
    id: weather

    property bool focused: false

    property string cityName: ""
    property string weatherIcon: "🌡️"
    property string tempText: "--"
    property string unit: "C"
    property int humidity: 0
    property int wind: 0
    property var forecast: []

    property string mainText: weatherIcon + " " + tempText + "°" + unit

    property string tooltipText: {
        let lines = []
        if (cityName !== "")
            lines.push(cityName)
        lines.push(mainText)
        if (humidity > 0 || wind > 0)
            lines.push("Humidity: " + humidity + "%  Wind: " + wind + " km/h")
        if (forecast && forecast.length) {
            let fc = []
            for (let i = 0; i < forecast.length; i++) {
                let f = forecast[i]
                fc.push((f.d || "Day " + (i + 1)) + ": " + (f.icon || "") + " " +
                        (f.max !== undefined ? Math.round(f.max) : "") + "°/" +
                        (f.min !== undefined ? Math.round(f.min) : "") + "°")
            }
            lines.push(fc.join("   "))
        }
        lines.push("Left click: location | Right click: °C/°F")
        return lines.join("\n")
    }

    function applyWeather(src: string): void {
        if (!src)
            return
        try {
            let d = JSON.parse(src)
            if (d.city !== undefined) cityName = d.city || cityName
            if (d.icon !== undefined) weatherIcon = d.icon || weatherIcon
            if (d.temp !== undefined) tempText = String(Math.round(d.temp))
            if (d.unit !== undefined) unit = d.unit
            if (d.humidity !== undefined) humidity = Math.round(d.humidity)
            if (d.wind !== undefined) wind = Math.round(d.wind)
            if (d.forecast !== undefined) forecast = d.forecast || []
        } catch (e) {
        }
    }

    function refresh(): void {
        weatherProc.running = false
        weatherProc.running = true
    }

    implicitWidth: card.implicitWidth + 8
    implicitHeight: card.implicitHeight + 4

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: content.implicitWidth + 20
        height: content.implicitHeight + 10
        radius: 12
        color: weather.focused ? Theme.primary : "transparent"
        border.width: 1
        border.color: weather.focused ? Theme.primary : Qt.rgba(Theme.on_primary.r, Theme.on_primary.g, Theme.on_primary.b, 0.15)
        z: -1

        Column {
            id: content
            anchors.centerIn: parent
            spacing: 2

            Row {
                spacing: 6
                anchors.horizontalCenter: parent.horizontalCenter

                Text {
                    text: weather.weatherIcon
                    font.pixelSize: 18
                    color: weather.focused ? Theme.background : Theme.primary
                }
                Text {
                    text: weather.tempText + "°" + weather.unit
                    font.family: Theme.fontFamily
                    font.pixelSize: 17
                    font.bold: true
                    color: weather.focused ? Theme.background : Theme.primary
                }
            }

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: weather.cityName
                font.family: Theme.fontFamily
                font.pixelSize: 9
                color: weather.focused ? Theme.background : Theme.primary
                opacity: 0.8
                visible: text !== ""
            }

            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 8

                Repeater {
                    model: weather.forecast
                    delegate: Column {
                        spacing: 0
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: modelData.d || ""
                            font.family: Theme.fontFamily
                            font.pixelSize: 8
                            color: weather.focused ? Theme.background : Theme.primary
                            opacity: 0.7
                        }
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: (modelData.icon || "") + " " +
                                  (modelData.max !== undefined ? Math.round(modelData.max) : "") + "/" +
                                  (modelData.min !== undefined ? Math.round(modelData.min) : "")
                            font.family: Theme.fontFamily
                            font.pixelSize: 9
                            color: weather.focused ? Theme.background : Theme.primary
                        }
                    }
                }
            }
        }
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        cursorShape: Qt.PointingHandCursor
        onClicked: mouse => {
            if (mouse.button === Qt.RightButton) {
                Quickshell.execDetached(["bash", "-c",
                    "u=$(cat \"$HOME/.config/quickshell/StatusbarApp/weather-unit.txt\" 2>/dev/null || printf C);" +
                    " if [ \"$u\" = F ]; then printf C > \"$HOME/.config/quickshell/StatusbarApp/weather-unit.txt\";" +
                    " else printf F > \"$HOME/.config/quickshell/StatusbarApp/weather-unit.txt\"; fi;" +
                    " qs ipc call weather refresh"])
            } else {
                Quickshell.execDetached(["bash", "-c",
                    Quickshell.env("HOME") + "/.config/quickshell/StatusbarApp/weather-set-location.sh"])
            }
        }
    }

    ToolTip {
        id: tip
        text: weather.tooltipText
        visible: mouseArea.containsMouse
        delay: 400
        timeout: 0
    }

    Process {
        id: weatherProc
        command: [Quickshell.env("HOME") + "/.config/quickshell/StatusbarApp/weather.sh"]
        running: true
        stdout: StdioCollector {
            onStreamFinished: weather.applyWeather(this.text.trim())
        }
    }

    FileView {
        id: cacheFile
        path: Quickshell.env("HOME") + "/.config/quickshell/StatusbarApp/weather-cache.txt"
        blockLoading: true
        printErrors: false
        onLoaded: weather.applyWeather(this.text().trim())
        onLoadFailed: { }
    }

    Timer {
        interval: 15 * 60 * 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: weatherProc.running = true
    }

    IpcHandler {
        target: "weather"
        function refresh(): void { weather.refresh() }
    }
}

#!/usr/bin/env bash
set -u

query="${1:-}"
if [ -z "$query" ] || [ "${#query}" -lt 2 ]; then
    echo "Type to search cities..."
    exit 0
fi

ENCODED="$(python3 -c 'import urllib.parse, sys; print(urllib.parse.quote(sys.argv[1]))' "$query" 2>/dev/null || printf '%s' "$query")"

curl -fsS --max-time 6 \
    "https://geocoding-api.open-meteo.com/v1/search?name=${ENCODED}&count=8&language=en" 2>/dev/null |
python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
except Exception:
    d = {}
results = d.get("results") or []
if not results:
    print("No matches")
    raise SystemExit
seen = set()
for r in results:
    name = r.get("name", "")
    country = r.get("country", "")
    admin = r.get("admin1", "")
    label = name
    if admin and admin != name:
        label += ", " + admin
    if country:
        label += " (" + country + ")"
    if label not in seen:
        seen.add(label)
        print(label)
'
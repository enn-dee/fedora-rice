import Quickshell
import Quickshell.Io
import QtQuick
import qs.CustomTheme

// Compact live CPU usage module.
// Reads /proc/stat, computes the delta between two samples, and shows a
// percentage that updates once per second.
Item {
    id: cpu

    property bool focused: false

    // Previous sample totals used for the delta calculation.
    property double prevTotal: 0
    property double prevIdle: 0
    property bool hasPrev: false

    property string text: "CPU --%"

    function refresh(): void {
        cpuProc.running = false
        cpuProc.running = true
    }

    implicitWidth: cpuText.implicitWidth + 6
    implicitHeight: 26

    Text {
        id: cpuText
        anchors.centerIn: parent
        text: cpu.text
        color: "#FFFFFF"
        Behavior on color { ColorAnimation { duration: 200 } }
        font.family: Theme.fontFamily
        font.pixelSize: 12
        font.bold: true
    }

    Rectangle {
        anchors.fill: parent
        radius: 13
        color: cpu.focused ? Theme.primary : "transparent"
        z: -1
        Behavior on color { ColorAnimation { duration: 500; easing.type: Easing.OutQuint } }
    }

    Process {
        id: cpuProc
        command: ["bash", "-c", "head -n 1 /proc/stat"]
        stdout: StdioCollector {
            onStreamFinished: {
                let line = this.text.trim()
                if (line === "")
                    return
                let parts = line.split(/\s+/)
                if (parts.length < 5 || parts[0] !== "cpu")
                    return
                let nums = []
                for (let i = 1; i < parts.length; i++)
                    nums.push(Number(parts[i]) || 0)
                let idle = (nums[3] || 0) + (nums[4] || 0)
                let total = 0
                for (let i = 0; i < nums.length; i++)
                    total += nums[i]
                if (cpu.hasPrev) {
                    let dt = total - cpu.prevTotal
                    let di = idle - cpu.prevIdle
                    let usage = (dt > 0) ? (100.0 * (dt - di) / dt) : 0
                    cpu.text = "CPU " + Math.round(usage) + "%"
                }
                cpu.prevTotal = total
                cpu.prevIdle = idle
                cpu.hasPrev = true
            }
        }
    }

    Timer {
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: cpu.refresh()
    }

    IpcHandler {
        target: "cpu"
        function refresh(): void { cpu.refresh() }
    }
}

import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import qs.CustomTheme

// Shows an icon chip for every app window currently open in Hyprland.
// Clicking a chip focuses that app's window.
RowLayout {
    id: root
    spacing: 8

    // Map a Hyprland window class to a short icon label.
    function appIcon(cls): string {
        let c = (cls || "").toLowerCase()
        if (c.indexOf("kitty") !== -1)      return "T"   // terminal
        if (c.indexOf("firefox") !== -1)     return "F"   // browser
        if (c.indexOf("brave") !== -1)       return "B"   // browser
        if (c.indexOf("chromium") !== -1)    return "C"   // browser
        if (c.indexOf("waybar") !== -1)      return "W"
        if (c.indexOf("dolphin") !== -1)     return "D"   // files
        if (c.indexOf("nautilus") !== -1)    return "D"
        if (c.indexOf("thunar") !== -1)      return "D"
        if (c.indexOf("code") !== -1)        return "V"   // vscode
        if (c.indexOf("nvim") !== -1)        return "N"
        if (c.indexOf("vim") !== -1)         return "N"
        if (c.indexOf("spotify") !== -1)     return "S"
        if (c.indexOf("discord") !== -1)     return "X"
        if (c.indexOf("telegram") !== -1)    return "Tg"
        if (c.indexOf("whatsapp") !== -1)    return "Wa"
        if (c.indexOf("obsidian") !== -1)    return "O"
        if (c.indexOf("rofi") !== -1)        return "R"
        if (c.indexOf("kitty") !== -1)       return "T"
        return cls ? cls.slice(0, 1).toUpperCase() : "?"
    }

    property var chips: []

    function refresh(): void {
        clientsProc.running = false
        clientsProc.running = true
    }

    Process {
        id: clientsProc
        command: ["bash", "-c", "hyprctl clients -j 2>/dev/null"]
        stdout: StdioCollector {
            onStreamFinished: {
                let text = this.text.trim()
                if (text === "") { root.chips = []; return }
                let arr
                try { arr = JSON.parse(text) } catch (e) { root.chips = []; return }
                let list = []
                for (let i = 0; i < arr.length; i++) {
                    let w = arr[i]
                    if (w.pinned) continue
                    if (w.workspace.name === "special") continue
                    if (!w.class || !w.title) continue
                    list.push({ cls: w.class, title: w.title, addr: w.address })
                }
                root.chips = list
            }
        }
    }

    Timer {
        interval: 2000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }

    Repeater {
        model: root.chips
        delegate: Rectangle {
            id: chip
            implicitWidth: 30
            implicitHeight: 26
            radius: 13
            color: "#FFFFFF1A"
            Behavior on color { ColorAnimation { duration: 200 } }

            Text {
                anchors.centerIn: parent
                text: root.appIcon(modelData.cls)
                color: "#FFFFFF"
                font.family: Theme.fontFamily
                font.pixelSize: 11
                font.bold: true
            }

            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Quickshell.execDetached([
                    "hyprctl", "dispatch", "focuswindow", "address:" + modelData.addr
                ])
            }
        }
    }

    Component.onCompleted: root.refresh()
}

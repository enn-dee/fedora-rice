import Quickshell
import Quickshell.Io
import QtQuick
import qs.CustomTheme

// Bluetooth status / toggle button.
// Shows "BT" with a dot when a device is connected, otherwise just "BT".
// Click opens blueberry if installed, otherwise bluetoothctl toggling via a
// terminal.
Item {
    id: bluetooth

    property bool focused: false
    property string text: "BT"
    property bool connected: false

    implicitWidth: btText.implicitWidth + 6
    implicitHeight: 26

    Text {
        id: btText
        anchors.centerIn: parent
        text: bluetooth.text
        color: "#FFFFFF"
        Behavior on color { ColorAnimation { duration: 200 } }
        font.family: Theme.fontFamily
        font.pixelSize: 12
        font.bold: true
    }

    Rectangle {
        anchors.fill: parent
        radius: 13
        color: bluetooth.focused ? Theme.primary : "transparent"
        z: -1
        Behavior on color { ColorAnimation { duration: 500; easing.type: Easing.OutQuint } }
    }

    function refresh(): void {
        btProc.running = false
        btProc.running = true
    }

    Process {
        id: btProc
        command: ["bash", "-c", "bluetoothctl show"]
        stdout: StdioCollector {
            onStreamFinished: {
                let text = this.text
                let powered = text.match(/Powered:\s*(yes|no)/)
                let conn = text.match(/Connected:\s*(yes|no)/)
                bluetooth.connected = (conn && conn[1] === "yes")
                bluetooth.text = bluetooth.connected ? "BT ●" : "BT"
            }
        }
    }

    Timer {
        interval: 3000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: bluetooth.refresh()
    }

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: {
            // Prefer the GUI manager if present, otherwise toggle via terminal.
            if (Qt.platform.os === "linux") {
                Quickshell.execDetached(["bash", "-c",
                    "which blueberry >/dev/null 2>&1 && blueberry"
                    + " || kitty -e bluetoothctl power toggle"])
            }
        }
    }

    IpcHandler {
        target: "bluetooth"
        function refresh(): void { bluetooth.refresh() }
    }
}

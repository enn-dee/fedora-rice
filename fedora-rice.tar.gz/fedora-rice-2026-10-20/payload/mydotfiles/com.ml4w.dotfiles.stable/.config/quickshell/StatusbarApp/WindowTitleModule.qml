import Quickshell
import Quickshell.Io
import QtQuick
import qs.CustomTheme

// Active window title from Hyprland (truncated to fit).
// Click does nothing by default — it is a read-only info chip.
Item {
    id: window

    property bool focused: false
    property string text: ""

    implicitWidth: winText.implicitWidth + 6
    implicitHeight: 26

    Text {
        id: winText
        anchors.centerIn: parent
        text: window.text
        color: "#FFFFFF"
        Behavior on color { ColorAnimation { duration: 200 } }
        elide: Text.ElideRight
        font.family: Theme.fontFamily
        font.pixelSize: 12
        font.bold: true
    }

    Rectangle {
        anchors.fill: parent
        radius: 13
        color: window.focused ? Theme.primary : "transparent"
        z: -1
        Behavior on color { ColorAnimation { duration: 500; easing.type: Easing.OutQuint } }
    }

    function refresh(): void {
        winProc.running = false
        winProc.running = true
    }

    Process {
        id: winProc
        command: ["bash", "-c",
            "hyprctl activewindow -j 2>/dev/null | grep '\"title\"' | head -n1"]
        stdout: StdioCollector {
            onStreamFinished: {
                let line = this.text.trim()
                let m = line.match(/\"title\":\s*\"(.*)\"/)
                let title = m ? m[1] : ""
                if (title.length > 45) title = title.slice(0, 42) + "..."
                window.text = title === "" ? "No window" : title
            }
        }
    }

    Timer {
        interval: 2000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: window.refresh()
    }

    IpcHandler {
        target: "window"
        function refresh(): void { window.refresh() }
    }
}

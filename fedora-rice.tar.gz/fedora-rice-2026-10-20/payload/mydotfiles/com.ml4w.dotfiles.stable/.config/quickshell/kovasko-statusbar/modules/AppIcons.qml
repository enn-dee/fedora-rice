import Quickshell
import Quickshell.Io
import Quickshell.Widgets
import QtQuick
import QtQuick.Layouts
import "../"

// Real app icons for every open window, shown to the right of the workspaces.
// Clicking an icon focuses that window; the focused window is highlighted.
RowLayout {
	id: root
	spacing: 6

	property var windows: []

	function refresh(): void {
		clientsProc.running = false
		clientsProc.running = true
	}

	// Resolve a window class to a real icon path.
	function iconFor(cls): string {
		if (!cls)
			return Quickshell.iconPath("application-x-executable", true)

		// 1) best match: the desktop entry for this app class
		var de = DesktopEntries.heuristicLookup(cls)
		if (de && de.icon)
			return Quickshell.iconPath(de.icon, true)

		// 2) the class name itself is often a valid icon-theme name
		if (Quickshell.hasThemeIcon(cls))
			return Quickshell.iconPath(cls, true)

		var lc = cls.toLowerCase()
		if (Quickshell.hasThemeIcon(lc))
			return Quickshell.iconPath(lc, true)

		// 3) generic fallback so there is never an empty slot
		return Quickshell.iconPath("application-x-executable", true)
	}

	Process {
		id: clientsProc
		command: ["bash", "-c", "hyprctl clients -j 2>/dev/null"]
		stdout: StdioCollector {
			onStreamFinished: {
				var t = this.text.trim()
				if (t === "") { root.windows = []; return }
				var arr
				try { arr = JSON.parse(t) } catch (e) { root.windows = []; return }
				var list = []
				for (var i = 0; i < arr.length; i++) {
					var w = arr[i]
					if (w.pinned) continue
					if (w.workspace && w.workspace.name === "special") continue
					if (!w.class) continue
					list.push({
						icon: root.iconFor(w.class),
						title: w.title,
						cls: w.class,
						addr: w.address,
						active: w.focusHistoryID === 0
					})
				}
				root.windows = list
			}
		}
	}

	Timer {
		interval: 1500
		running: true
		repeat: true
		triggeredOnStart: true
		onTriggered: root.refresh()
	}

	Repeater {
		model: root.windows

		delegate: Item {
			id: cell
			implicitWidth: 22
			implicitHeight: 22

			// subtle pill behind the focused window's icon
			Rectangle {
				anchors.fill: parent
				radius: 6
				color: modelData.active ? Qt.rgba(1, 1, 1, 0.16) : "transparent"
			}

			IconImage {
				anchors.centerIn: parent
				implicitSize: 16
				source: modelData.icon
			}

			MouseArea {
				anchors.fill: parent
				hoverEnabled: true
				cursorShape: Qt.PointingHandCursor
				onClicked: Quickshell.execDetached([
					"hyprctl", "dispatch", "focuswindow", "address:" + modelData.addr
				])
			}
		}
	}

	Component.onCompleted: root.refresh()
}

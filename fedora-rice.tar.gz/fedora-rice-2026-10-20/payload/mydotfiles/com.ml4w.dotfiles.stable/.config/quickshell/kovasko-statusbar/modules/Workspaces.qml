import QtQuick
import QtQuick.Layouts
import Quickshell.Hyprland
import "../"

Repeater {
	model: 5
	
	Rectangle {
		Layout.preferredWidth: 20
		Layout.preferredHeight: 26
		color: "transparent"
		
		property var workspace: Hyprland.workspaces.values.find(ws => ws.id === index + 1) ?? null
		property bool isActive: Hyprland.focusedWorkspace?.id === (index + 1)
		property bool hasWindows: workspace !== null
		
		Text {
			text: index + 1
			color: parent.isActive ? Theme.colLavenda : (parent.hasWindows ? Theme.colLavenda : Theme.colFg)
			font.pixelSize: Theme.fontSize
			font.family: Theme.fontFamily
			font.bold: true
			anchors.centerIn: parent
		}
		
		// Dot indicator (replaces the old bottom bar).
		// Active workspace: larger, bright dot. Others: small, dim dot.
		Rectangle {
			width: parent.isActive ? 6 : 4
			height: width
			radius: width / 2
			color: parent.isActive ? Theme.colPurple : Theme.colFg
			opacity: parent.isActive ? 1.0 : 0.45
			anchors.horizontalCenter: parent.horizontalCenter
			anchors.bottom: parent.bottom
			anchors.bottomMargin: 3
			Behavior on width { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
			Behavior on color { ColorAnimation { duration: 160 } }
			Behavior on opacity { NumberAnimation { duration: 160 } }
		}
		
		MouseArea {
			anchors.fill: parent
			onClicked: Hyprland.dispatch("workspace " + (index + 1))
		}
	}
}

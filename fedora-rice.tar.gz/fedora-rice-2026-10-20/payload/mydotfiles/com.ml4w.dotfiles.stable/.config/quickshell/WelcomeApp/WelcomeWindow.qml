import Quickshell
import Quickshell.Hyprland
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import Quickshell.Io
import qs.CustomTheme

FloatingWindow {
    id: root
    visible: false
    title: "ML4W Welcome"
    implicitWidth: 850
    implicitHeight: 550

    // --- Guard property for the flatpak app ---
    property bool isHyprlandSettingsInstalled: false

    // --- Version read from the shipped version.json ---
    property string version: ""

    FileView {
        id: versionFile
        path: Quickshell.env("HOME") + "/.config/ml4w/version.json"
        blockLoading: true
        printErrors: false
        onLoaded: {
            try {
                root.version = JSON.parse(this.text()).Version || ""
            } catch (e) {
                root.version = ""
            }
        }
        onLoadFailed: root.version = ""
    }

    // Re-read version.json every time the window is shown, so an update that
    // happened while the window was hidden is picked up.
    onVisibleChanged: {
        if (root.visible)
            versionFile.reload()
    }

    IpcHandler {
        target: "welcome"
        function toggle(): void {
            root.visible = !root.visible
        }
    }

    // --- Check if flatpak is installed when window opens ---
    Process {
        command: ["bash", "-c", Quickshell.env("HOME") + "/.config/ml4w/scripts/ml4w-command-exists hyprmod"]
        running: root.visible
        
        stdout: StdioCollector {
            onStreamFinished: {
                console.log(this.text.trim())
                // The script echoes "0" if the app exists/is installed
                root.isHyprlandSettingsInstalled = (this.text.trim() === "0")
            }
        }
    }

    // Define a custom reusable styled MenuItem
    component ML4WMenuItem: MenuItem {
        id: control
        
        contentItem: Text {
            text: control.text
            font.family: Theme.fontFamily
            font.pixelSize: 14
            // Invert colors on hover
            color: control.highlighted ? Theme.background : Theme.primary 
            verticalAlignment: Text.AlignVCenter
        }
        
        background: Rectangle {
            implicitWidth: 220
            implicitHeight: 36
            // Apply theme color on hover
            color: control.highlighted ? Theme.primary : "transparent"
            radius: 4
        }
    }

    component ML4WMenuSeparator: MenuSeparator {
        contentItem: Rectangle {
            implicitWidth: 200
            implicitHeight: 1
            color: Theme.primary
            opacity: 0.3 // Dim the line so it doesn't distract from text
        }
    }

    color: Theme.background

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        // ==========================================
        // TRADITIONAL MENU BAR
        // ==========================================
        MenuBar {
            Layout.fillWidth: true
            Layout.margins: 10
            background: Rectangle {
                color: Theme.primary
                border.color: Theme.primary
                radius: 8
            }

            // --- SETTINGS MENU ---
            Menu {
                title: qsTr("Settings")
                font.family: Theme.fontFamily
                font.pixelSize: 14
                padding:8

                enter: Transition { NumberAnimation { property: "opacity"; from: 0.0; to: 1.0; duration: 200; easing.type: Easing.OutQuad } }
                exit: Transition { NumberAnimation { property: "opacity"; from: 1.0; to: 0.0; duration: 150; easing.type: Easing.InQuad } }

                ML4WMenuItem { 
                    text: qsTr("Input");
                    onClicked: {
                        Quickshell.execDetached(["gnome-text-editor", Quickshell.env("HOME") + "/.config/hypr/input.lua"])
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Gestures");
                    onClicked: {
                        Quickshell.execDetached(["gnome-text-editor", Quickshell.env("HOME") + "/.config/hypr/gestures.lua"])
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Monitors");
                    onClicked: { 
                        // Quickshell.execDetached(["gnome-text-editor", Quickshell.env("HOME") + "/.config/hypr/monitors.lua"])
                        Quickshell.execDetached(["nwg-displays"]) 
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Network");
                    onClicked: { 
                        Quickshell.execDetached(["kitty", "--class", "dotfiles-floating", "-e", Quickshell.env("HOME") + "/.config/ml4w/scripts/ml4w-network"])
                    }
                }    
                ML4WMenuItem { 
                    text: qsTr("Bluetooth");
                    onClicked: { 
                        Quickshell.execDetached(["blueman-manager"])
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Wallpaper");
                    onClicked: { 
                        Quickshell.execDetached(["bash", "-c", Quickshell.env("HOME") + "/.config/ml4w/scripts/ml4w-wallpaper-app"])
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Theme");
                    onClicked: { 
                        Quickshell.execDetached(["nwg-look"])
                    }
                }
                ML4WMenuSeparator {}
                ML4WMenuItem { 
                    text: qsTr("Sidebar");
                    onClicked: {
                        Quickshell.execDetached(["qs", "ipc", "call", "sidebar", "toggle"])
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Dotfiles Settings");
                    onClicked: {
                        Quickshell.execDetached(["qs", "-p", Quickshell.env("HOME") + "/.local/share/ml4w-dotfiles-settings/quickshell", "ipc", "call", "settings", "toggle"])
                    }
                }
                ML4WMenuItem { 
                    text: root.isHyprlandSettingsInstalled ? qsTr("HyprMod") : qsTr("Install HyprMod")
                    onClicked: { 
                        if (root.isHyprlandSettingsInstalled) {
                            Quickshell.execDetached(["hyprmod"])
                        } else {
                            Quickshell.execDetached(["kitty", "--class", "dotfiles-floating", "-e", Quickshell.env("HOME") + "/.config/ml4w/scripts/ml4w-install-hyprmod"])
                        }
                    }
                }
                background: Rectangle {
                    implicitWidth: 220
                    color: Theme.background
                    border.color: Theme.primary
                    border.width: 1
                    radius: 8
                }
            }

            // --- System MENU ---
            Menu {
                title: qsTr("System")
                font.family: Theme.fontFamily
                font.pixelSize: 14
                padding:8
                
                enter: Transition { NumberAnimation { property: "opacity"; from: 0.0; to: 1.0; duration: 200; easing.type: Easing.OutQuad } }
                exit: Transition { NumberAnimation { property: "opacity"; from: 1.0; to: 0.0; duration: 150; easing.type: Easing.InQuad } }

                ML4WMenuItem { 
                    text: qsTr("Display Manager");
                    onClicked: { 
                        Quickshell.execDetached(["kitty", "--class", "dotfiles-floating", "-e", Quickshell.env("HOME") + "/.config/ml4w/scripts/ml4w-install-sddm"]) 
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Network Manager Applet");
                    onClicked: { 
                        Quickshell.execDetached(["bash", "-c", Quickshell.env("HOME") + "/.config/ml4w/scripts/ml4w-toggle-nmapplet"])
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Change Shell");
                    onClicked: { 
                        Quickshell.execDetached(["kitty", "--class", "dotfiles-floating", "-e", Quickshell.env("HOME") + "/.config/ml4w/scripts/ml4w-change-shell"])
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("System Info") 
                    onClicked: { 
                        Quickshell.execDetached(["bash", "-c", Quickshell.env("HOME") + "/.config/ml4w/scripts/ml4w-hyprsysteminfo"])
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Open .mydotfiles Folder") 
                    onClicked: { 
                        // Opens the dotfiles folder in the filemanager
                        // configured in the dotfiles settings.
                        Quickshell.execDetached(["bash", "-c", "$(cat ~/.config/ml4w/settings/filemanager) ~/.mydotfiles"])
                    }
                }
                ML4WMenuItem { 
                    text: qsTr("Open Backup Folder") 
                    onClicked: { 
                        // Opens the dotfiles backup folder in the filemanager
                        // configured in the dotfiles settings.
                        Quickshell.execDetached(["bash", "-c", "$(cat ~/.config/ml4w/settings/filemanager) ~/.mydotfiles/backups"])
                    }
                }
                ML4WMenuSeparator {}
                ML4WMenuItem { 
                    text: qsTr("Exit Hyprland") 
                    onClicked: {
                        Quickshell.execDetached(["bash", "-c", "ml4w-powermenu toggle"])
                    }
                }

                background: Rectangle {
                    implicitWidth: 220
                    color: Theme.background
                    border.color: Theme.primary
                    border.width: 1
                    radius: 8
                }
            }

            // --- HELP MENU ---
            Menu {
                title: qsTr("Help")
                font.family: Theme.fontFamily
                font.pixelSize: 14
                padding:8
                
                enter: Transition { NumberAnimation { property: "opacity"; from: 0.0; to: 1.0; duration: 200; easing.type: Easing.OutQuad } }
                exit: Transition { NumberAnimation { property: "opacity"; from: 1.0; to: 0.0; duration: 150; easing.type: Easing.InQuad } }

                ML4WMenuItem { text: qsTr("ML4W OS Homepage"); onClicked: { 
                    Quickshell.execDetached(["xdg-open", "https://ml4w.com/os/"])
                    }
                }
                ML4WMenuItem { text: qsTr("ML4W OS GitHub"); onClicked: { 
                    Quickshell.execDetached(["xdg-open", "https://github.com/mylinuxforwork/dotfiles"]) 
                    } 
                }
                ML4WMenuItem { text: qsTr("ML4W OS Changelog"); onClicked: { 
                    Quickshell.execDetached(["xdg-open", "https://github.com/mylinuxforwork/dotfiles/blob/main/CHANGELOG.md"]) 
                    } 
                }
                ML4WMenuItem { text: qsTr("ML4W YouTube Channel"); onClicked: { 
                    Quickshell.execDetached(["xdg-open", "https://www.youtube.com/channel/UC0sUzmZ0CHvVCVrpRfGKZfw"]) 
                    } 
                }
                ML4WMenuItem { text: qsTr("Get more Wallpapers"); onClicked: { 
                    Quickshell.execDetached(["xdg-open", "https://github.com/mylinuxforwork/wallpaper"]) 
                    } 
                }
                ML4WMenuSeparator {}
                ML4WMenuItem { text: qsTr("Hyprland Homepage"); onClicked: { 
                    Quickshell.execDetached(["xdg-open", "https://github.com/mylinuxforwork/wallpaper"]) 
                    } 
                }
                ML4WMenuItem { text: qsTr("Hyprland Wiki"); onClicked: { 
                    Quickshell.execDetached(["xdg-open", "https://github.com/mylinuxforwork/wallpaper"]) 
                    } 
                }
                ML4WMenuItem { text: qsTr("Update ML4W OS"); onClicked: { 
                    Quickshell.execDetached(["xdg-open", "https://ml4w.com/os/getting-started/update"]) 
                    } 
                }

                background: Rectangle {
                    implicitWidth: 180
                    color: Theme.background
                    border.color: Theme.primary
                    radius: 8
                }
            }

            // --- UNIVERSAL STYLING FOR ALL MENUS ---
            delegate: MenuBarItem {
                id: menuBarItem
                contentItem: Text {
                    text: menuBarItem.text
                    font.pixelSize: 14
                    font.family: Theme.fontFamily
                    color: Theme.on_primary
                    horizontalAlignment: Text.AlignLeft
                    verticalAlignment: Text.AlignVCenter
                }
                background: Rectangle {
                    color: "transparent"
                    radius: Theme.on_primary
                }
            }
        }

        // ==========================================
        // MAIN CONTENT AREA
        // ==========================================
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            color: "transparent"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 10
                spacing: 10

                // --- MAIN HERO SECTION --- 
                ColumnLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 5
                    Layout.topMargin: 20

                    Image {
                        Layout.alignment: Qt.AlignHCenter
                        source: "../shared/ml4w.svg"
                        sourceSize.width: 100 
                        sourceSize.height: 100
                        width: 100
                        height: 100
                        fillMode: Image.PreserveAspectFit
                    }

                    Text {
                        Layout.alignment: Qt.AlignHCenter
                        text: "Welcome to ML4W OS"
                        font.family: Theme.fontFamily
                        font.pixelSize: 28
                        font.bold: true
                        color: Theme.on_background
                        Layout.bottomMargin: 0
                    }

                    Text {
                        Layout.alignment: Qt.AlignHCenter
                        text: "Version " + root.version
                        visible: root.version !== ""
                        font.family: Theme.fontFamily
                        font.pixelSize: 16
                        color: Theme.on_background
                        Layout.bottomMargin: 10
                    }

                    // Action Buttons
                    RowLayout {
                        Layout.alignment: Qt.AlignHCenter
                        spacing: 15

                        Button {
                            text: "Dotfiles Settings"
                            onClicked: {
                                Quickshell.execDetached(["qs", "-p", Quickshell.env("HOME") + "/.local/share/ml4w-dotfiles-settings/quickshell", "ipc", "call", "settings", "toggle"])
                            }
                            background: Rectangle {
                                color: "transparent"
                                radius: 10
                                border.color: Theme.primary
                            }
                            contentItem: Text {
                                text: parent.text
                                font.family: Theme.fontFamily
                                color: Theme.primary
                                padding: 8
                            }
                        }

                        // --- VISIBILITY BOUND TO GUARD PROPERTY ---
                        Button {
                            text: "HyprMod"
                            visible: root.isHyprlandSettingsInstalled 
                            
                            onClicked: {
                                Quickshell.execDetached(["hyprmod"])
                            }
                            background: Rectangle {
                                color: "transparent"
                                radius: 10
                                border.color: Theme.primary
                            }
                            contentItem: Text {
                                text: parent.text
                                font.family: Theme.fontFamily
                                color: Theme.primary
                                padding: 8
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true } // Spacer

                // --- KEYBINDINGS GRID ---
                ColumnLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 8

                    Repeater {
                        model: ListModel {
                            ListElement { keys: "Super + Enter"; desc: "to open the terminal" }
                            ListElement { keys: "Super + B"; desc: "to open the browser" }
                            ListElement { keys: "Super + Q"; desc: "to close the active window" }
                            ListElement { keys: "Super + CTRL + Enter"; desc: "to open the application launcher" }
                            ListElement { keys: "Super + CTRL + S"; desc: "to open the sidebar" }
                            ListElement { keys: "Super + CTRL + W"; desc: "to set a wallpaper" }
                        }
                        
                        delegate: RowLayout {
                            spacing: 15
                            
                            Text {
                                text: model.keys
                                color: Theme.primary
                                font.family: Theme.fontFamily
                                font.bold: true
                                font.pixelSize: 13
                                Layout.preferredWidth: 120
                                horizontalAlignment: Text.AlignRight
                            }
                            
                            Text {
                                text: model.desc
                                color: Theme.on_background
                                font.family: Theme.fontFamily
                                font.pixelSize: 13
                                Layout.preferredWidth: 240
                            }
                        }
                    }

                    RowLayout {
                        Layout.alignment: Qt.AlignHCenter
                        Layout.topMargin: 15
                        spacing: 8

                        Button {
                            text: "Input"

                            onClicked: {
                                Quickshell.execDetached(["gnome-text-editor", Quickshell.env("HOME") + "/.config/hypr/input.lua"])
                            }

                            background: Rectangle {
                                color: "transparent"
                                border.color: Theme.primary
                                radius: 10
                            }
                            contentItem: Text {
                                text: parent.text
                                font.family: Theme.fontFamily
                                color: Theme.primary
                                padding: 8
                            }
                        }

                        Button {
                            text: "Monitors"

                            onClicked: {
                                Quickshell.execDetached(["nwg-displays"])
                            }

                            background: Rectangle {
                                color: "transparent"
                                border.color: Theme.primary
                                radius: 10
                            }
                            contentItem: Text {
                                text: parent.text
                                font.family: Theme.fontFamily
                                color: Theme.primary
                                padding: 8
                            }
                        }

                        Button {
                            text: "All Keybinds"

                            onClicked: {
                                Quickshell.execDetached(["bash", "-c", Quickshell.env("HOME") + "/.config/hypr/scripts/keybindings.sh"])
                            }

                            background: Rectangle {
                                color: "transparent"
                                border.color: Theme.primary
                                radius: 10
                            }
                            contentItem: Text {
                                text: parent.text
                                font.family: Theme.fontFamily
                                color: Theme.primary
                                padding: 8
                            }
                        }
                    }
                }
                
                Item { Layout.fillHeight: true } 

                // ==========================================
                // BOTTOM BAR
                // ==========================================
                RowLayout {
                    Layout.fillWidth: true
                    Layout.margins: 10

                    // --- CLOSE BUTTON (Left Side) ---
                    Button {
                        text: "Close"

                        background: Rectangle {
                            color: "transparent"
                            border.color: Theme.primary
                            border.width: 1
                            radius: 6
                        }

                        contentItem: Text {
                            text: parent.text
                            font.family: Theme.fontFamily
                            font.pixelSize: 12
                            color: Theme.primary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                            padding: 4
                            leftPadding: 10
                            rightPadding: 10
                        }

                        onClicked: root.visible = !root.visible
                    }

                    // --- NEW TOGGLE BUTTON (Left Side) ---
                    Button {
                        text: "Toggle Tiling/Floating"
                        
                        // Styled to be slightly smaller and compact
                        background: Rectangle {
                            color: "transparent"
                            border.color: Theme.primary
                            border.width: 1
                            radius: 6
                        }
                        
                        contentItem: Text {
                            text: parent.text
                            font.family: Theme.fontFamily
                            font.pixelSize: 12 // Smaller text size
                            color: Theme.primary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                            padding: 4
                            leftPadding: 10
                            rightPadding: 10
                        }
                        
                        onClicked: {
                            // Hyprland with Lua dispatchers ignores the plain
                            // "togglefloating" string, so branch on usingLua the
                            // same way the overview and statusbar modules do.
                            if (Hyprland.usingLua)
                                Hyprland.dispatch("hl.dsp.window.float({ action = 'toggle' })")
                            else
                                Hyprland.dispatch("togglefloating")
                        }
                    }

                    Item { Layout.fillWidth: true }

                    Text {
                        text: qsTr("Show on Startup")
                        color: Theme.primary
                        font.family: Theme.fontFamily
                        font.pixelSize: 14
                        Layout.alignment: Qt.AlignVCenter
                    }

                    Switch {
                        id: autostartSwitch
                        Layout.alignment: Qt.AlignVCenter
                        
                        implicitWidth: 48
                        implicitHeight: 26

                        property bool ready: false

                        Process {
                            command: ["bash", "-c", "test -f ~/.cache/ml4w-welcome-autostart && echo exists || echo missing"]
                            running: root.visible
                            stdout: StdioCollector {
                                onStreamFinished: {
                                    let output = this.text.trim()
                                    if (output === "exists") {
                                        autostartSwitch.checked = false 
                                    } else if (output === "missing") {
                                        autostartSwitch.checked = true  
                                    }
                                    autostartSwitch.ready = true
                                }
                            }
                        }

                        indicator: Rectangle {
                            implicitWidth: 48
                            implicitHeight: 26
                            radius: 13
                            
                            color: autostartSwitch.checked ? Theme.primary : Theme.background
                            border.color: Theme.primary
                            border.width: 1

                            Rectangle {
                                x: autostartSwitch.checked ? parent.width - width - 2 : 2
                                y: 2
                                width: 22
                                height: 22 
                                radius: 11
                                color: autostartSwitch.checked ? Theme.background : Theme.on_primary
                                Behavior on x { NumberAnimation { duration: 150 } }
                            }
                        }

                        onClicked: {
                            if (!ready) return;
                            if (checked) {
                                Quickshell.execDetached(["rm", "-f", Quickshell.env("HOME") + "/.cache/ml4w-welcome-autostart"])
                            } else {
                                Quickshell.execDetached(["touch", Quickshell.env("HOME") + "/.cache/ml4w-welcome-autostart"])
                            }
                        }
                    }
                }                
            }
        }
    }
}

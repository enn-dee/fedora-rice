
background = "rgba(101418ff)"

error = "rgba(ffb4abff)"

error_container = "rgba(93000aff)"

inverse_on_surface = "rgba(2d3135ff)"

inverse_primary = "rgba(2d628cff)"

inverse_surface = "rgba(e0e2e8ff)"

on_background = "rgba(e0e2e8ff)"

on_error = "rgba(690005ff)"

on_error_container = "rgba(ffdad6ff)"

on_primary = "rgba(003352ff)"

on_primary_container = "rgba(cde5ffff)"

on_primary_fixed = "rgba(001d32ff)"

on_primary_fixed_variant = "rgba(0a4a72ff)"

on_secondary = "rgba(233240ff)"

on_secondary_container = "rgba(d4e4f6ff)"

on_secondary_fixed = "rgba(0e1d2aff)"

on_secondary_fixed_variant = "rgba(3a4857ff)"

on_surface = "rgba(e0e2e8ff)"

on_surface_variant = "rgba(c2c7cfff)"

on_tertiary = "rgba(382a49ff)"

on_tertiary_container = "rgba(eedcffff)"

on_tertiary_fixed = "rgba(221533ff)"

on_tertiary_fixed_variant = "rgba(4f4061ff)"

outline = "rgba(8c9198ff)"

outline_variant = "rgba(42474eff)"

primary = "rgba(9acbfaff)"

primary_container = "rgba(0a4a72ff)"

primary_fixed = "rgba(cde5ffff)"

primary_fixed_dim = "rgba(9acbfaff)"

scrim = "rgba(000000ff)"

secondary = "rgba(b9c8daff)"

secondary_container = "rgba(3a4857ff)"

secondary_fixed = "rgba(d4e4f6ff)"

secondary_fixed_dim = "rgba(b9c8daff)"

shadow = "rgba(000000ff)"

source_color = "rgba(228dd2ff)"

surface = "rgba(101418ff)"

surface_bright = "rgba(36393eff)"

surface_container = "rgba(1c2024ff)"

surface_container_high = "rgba(272a2eff)"

surface_container_highest = "rgba(313539ff)"

surface_container_low = "rgba(181c20ff)"

surface_container_lowest = "rgba(0b0f12ff)"

surface_dim = "rgba(101418ff)"

surface_tint = "rgba(9acbfaff)"

surface_variant = "rgba(42474eff)"

tertiary = "rgba(d2bfe7ff)"

tertiary_container = "rgba(4f4061ff)"

tertiary_fixed = "rgba(eedcffff)"

tertiary_fixed_dim = "rgba(d2bfe7ff)"


